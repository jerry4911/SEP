package hw01;

import java.io.*;
import org.junit.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.Assert.*;

class countNodesTest {
	AVLTreeTest test = new AVLTreeTest();
	private ByteArrayInputStream testIn;
	int insert_num = 0;
	
	@Test
	@DisplayName("�p��ž�node�ƶq")
	void test_empty() {
		String testString = "3\nn\n";
		testIn = new ByteArrayInputStream(testString.getBytes());
        System.setIn(testIn);
		test.main(new String[0]); 
		assertEquals( 0, test.getNodeNum() );
	}
	
	@Test
	@DisplayName("�p��D�ž�node�ƶq")
	void test_not_empty() {
		String testString = "";
//		insert_num = (int)(Math.random()*100)+1;
		insert_num = 20;
		for (int i=1; i<=insert_num; i++) {
			testString = testString + "1\n" + Integer.toString(i) + "\n";
			if (i==insert_num)
				testString = testString + "3\nn\n";
			else testString = testString + "y\n";
		}
		
		testIn = new ByteArrayInputStream(testString.getBytes());
        System.setIn(testIn);
		test.main(new String[0]); 	
		assertEquals( 0, test.getNodeNum() );
	}

}