package hw01;

import java.io.*;
import org.junit.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.Assert.*;

class insertionTest {
	AVLTreeTest test = new AVLTreeTest();
	private ByteArrayInputStream testIn;
	int insert_num = 0;
	
	@Test
	@DisplayName("insert 20 data")
	void test_20() {
		String testString = "";
		insert_num = 20;
		for (int i=1; i<=insert_num; i++) {
			int r = (int)(Math.random()*1000)+1;
			testString = testString + "1\n" + Integer.toString(r) + "\n";
			if (i==insert_num)
				testString = testString + "n\n";
			else testString = testString + "y\n";
		}

		testIn = new ByteArrayInputStream(testString.getBytes());
        System.setIn(testIn);
		test.main(new String[0]); 
	}
	
	@Test
	@DisplayName("insert 60 data")
	void test_60() {
		String testString = "";
		insert_num = 60;
		for (int i=1; i<=insert_num; i++) {
			int r = (int)(Math.random()*1000)+1;
			testString = testString + "1\n" + Integer.toString(r) + "\n";
			if (i==insert_num)
				testString = testString + "n\n";
			else testString = testString + "y\n";
		}

		testIn = new ByteArrayInputStream(testString.getBytes());
        System.setIn(testIn);
		test.main(new String[0]); 
	}
	
	@Test
	@DisplayName("insert 100 data")
	void test_100() {

		String testString = "";
		insert_num = 100;
		for (int i=1; i<=insert_num; i++) {
			int r = (int)(Math.random()*1000)+1;
			testString = testString + "1\n" + Integer.toString(r) + "\n";
			if (i==insert_num)
				testString = testString + "n\n";
			else testString = testString + "y\n";
		}

		testIn = new ByteArrayInputStream(testString.getBytes());
        System.setIn(testIn);
		test.main(new String[0]); 
	}

}
