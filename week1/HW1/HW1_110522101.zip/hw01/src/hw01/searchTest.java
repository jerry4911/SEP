package hw01;

import java.io.*;
import org.junit.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.Assert.*;

class searchTest {
	AVLTreeTest test = new AVLTreeTest();
	private ByteArrayInputStream testIn;
	int target = 0, insert_num = 0;
	
	@Test
	@DisplayName("search �i�H��쪺")
	void test_can_find() {
		String testString = "";
		insert_num = 20;
		
		for (int i=1; i<=insert_num; i++) {
			int r = (int)(Math.random()*1000)+1;
			testString = testString + "1\n" + Integer.toString(r) + "\ny\n";
			if (i==10) 
				target = r;
		}
		testString = testString + "2\n" + Integer.toString(target) + "\nn\n";
		
		testIn = new ByteArrayInputStream(testString.getBytes());
        System.setIn(testIn);
		test.main(new String[0]); 
		assertEquals( true, test.getSearch() );
	}
	
	@Test
	@DisplayName("search �䤣�쪺")
	void test_cannot_find() {
		String testString = "";
		int target, insert_num = 20;
		
		for (int i=1; i<=insert_num; i++) {
			int r = (int)(Math.random()*1000)+1;
			testString = testString + "1\n" + Integer.toString(r) + "\ny\n";
		}
		target = (int)(Math.random()*1000)+1001;
		testString = testString + "2\n" + Integer.toString(target) + "\nn\n";
		
		testIn = new ByteArrayInputStream(testString.getBytes());
        System.setIn(testIn);
		test.main(new String[0]); 
		assertEquals( false, test.getSearch() );

	}

}
